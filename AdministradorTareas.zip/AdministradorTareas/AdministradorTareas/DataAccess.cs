﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Configuration;
using System.Data;
using System.Data.Common;

namespace AdministradorTareas
{
    internal class DataAccess
    {
        private string connString = "Server=localhost;Port=5432;Database=gestionTareas;User Id=postgres;Password=adm;";


        public List<Task> GetAllTasks()
        {
            List<Task> tasks = new List<Task>();
            using (NpgsqlConnection conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("SELECT * FROM tasks", conn);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Task task = new Task();
                    task.Id = (int)reader["id"];
                    task.Title = reader["title"].ToString();
                    task.Description = reader["description"].ToString();
                    task.DueDate = (DateTime)reader["due_date"];
                    task.Completed = (bool)reader["completed"];
                    tasks.Add(task);
                }
            }
            return tasks;
        }

        public void AddTask(Task task)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO tasks (title, description, due_date, completed) VALUES (@Title, @Description, @DueDate, @Completed)", conn);
                cmd.Parameters.AddWithValue("@Title", task.Title);
                cmd.Parameters.AddWithValue("@Description", task.Description);
                cmd.Parameters.AddWithValue("@DueDate", task.DueDate);
                cmd.Parameters.AddWithValue("@Completed", task.Completed);
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateTask(Task task)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("UPDATE tasks SET title = @Title, description = @Description, due_date = @DueDate, completed = @Completed WHERE id = @Id", conn);
                cmd.Parameters.AddWithValue("@Title", task.Title);
                cmd.Parameters.AddWithValue("@Description", task.Description);
                cmd.Parameters.AddWithValue("@DueDate", task.DueDate);
                cmd.Parameters.AddWithValue("@Completed", task.Completed);
                cmd.Parameters.AddWithValue("@Id", task.Id);
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteTask(int id)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(connString))
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("DELETE FROM tasks WHERE id = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
        }



    }
}
