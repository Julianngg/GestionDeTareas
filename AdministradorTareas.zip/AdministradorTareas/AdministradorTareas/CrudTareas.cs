﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdministradorTareas
{
    public partial class CrudTareas : Form
    {
        public CrudTareas()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadTasks();
        }

        private DataAccess dataAccess = new DataAccess();

        private void LoadTasks()
        {
            List<Task> tasks = dataAccess.GetAllTasks();
            dataGridView1.DataSource = tasks;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Task task = new Task();
            task.Title = txtTitle.Text;
            task.Description = txtDescription.Text;
            task.DueDate = dtpDueDate.Value;
            task.Completed = chkCompleted.Checked;

            dataAccess.AddTask(task);
            LoadTasks();
        }


        private void button3_Click(object sender, EventArgs e)
        {
            int id = (int)dataGridView1.CurrentRow.Cells["Id"].Value;
            dataAccess.DeleteTask(id);
            LoadTasks();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Task task = new Task();
            task.Id = (int)dataGridView1.CurrentRow.Cells["Id"].Value;
            task.Title = (string)dataGridView1.CurrentRow.Cells["Title"].Value;
            task.Description = (string)dataGridView1.CurrentRow.Cells["Description"].Value;
            task.DueDate = (DateTime)dataGridView1.CurrentRow.Cells["DueDate"].Value;
            task.Completed = (Boolean)dataGridView1.CurrentRow.Cells["Completed"].Value; ;
            dataAccess.UpdateTask(task);
            LoadTasks();
        }

        private void chkCompleted_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
